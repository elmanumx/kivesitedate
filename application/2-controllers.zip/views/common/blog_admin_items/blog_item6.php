<!-- Block 6 :  text + text -->
<div class="blog_block AOnlyText row no-gutters a-bf-row_auto-height">
    <input type="hidden" name="blog[upload_file_name_n0][type]" value="6">
    <input class="blog_element_id" type="hidden" name="blog[upload_file_name_n0][id]" value="{element_id}">
    <input type="button" title="Click to delete this row" class="a-bf-row-delete delete_block">
    <div class="col-md-6 d-flex align-items-center">
        <div class="a-bf-only-text">
            <textarea name="blog[upload_file_name_n0][text1]" class="a-bf-only-text__paragraph text-center" placeholder="You can write an infinite number of characters in these blocks, but when you finish writing it, divide this text into two approximately identical parts so that it is in both columns.">{text1}</textarea>
        </div>
    </div>
    <div class="col-md-6 d-flex align-items-center">
        <div class="a-bf-only-text">
            <textarea name="blog[upload_file_name_n0][text2]" class="a-bf-only-text__paragraph text-center" placeholder="Paste here the second half of the text (these parts of the text do not have to be equal in volume)">{text2}</textarea>
        </div>
    </div>
</div>
