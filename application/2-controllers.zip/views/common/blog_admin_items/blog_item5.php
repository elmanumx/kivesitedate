<!-- Block 5 :  title -->
<div class="blog_block AHeadline row no-gutters a-bf-row_auto-height">
    <div class="col-12">
        <input type="hidden" name="blog[upload_file_name_n0][type]" value="5">
    <input class="blog_element_id" type="hidden" name="blog[upload_file_name_n0][id]" value="{element_id}">
        <input type="text" name="blog[upload_file_name_n0][title]" class="a-b__title text-center">
    </div>
    <input value="{title}" type="button" title="Click to delete this row" class="a-bf-row-delete delete_block-headline delete_block">
</div>
