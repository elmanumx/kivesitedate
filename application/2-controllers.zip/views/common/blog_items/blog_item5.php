<!-- Block 5 -->
<!-- <div class="row"><div class="col-12"><h2 class="b-full__title text-center">{title}</h2></div></div>
<!-- -->
<div class="row">
    <div class="col-12">
        <h2 class="b-full__title text-center">{title}</h2>
    </div>
</div>
