<!-- Block 4 -->
<!-- <div class="row no-gutters bf-row"><div class="col-md-6 order-md-2 d-flex align-items-center"><div class="bf-text-small"><h3 class="bf-text-small__title text-center">{title}</h3></div></div><div class="col-md-6 order-md-1 d-flex"><div class="bf-img-wrap"><img class="bf-img" src="{img}" alt=""></div></div></div>
<!-- -->
<div class="row no-gutters bf-row">
    <div class="col-md-6 order-md-2 d-flex align-items-center">
        <div class="bf-text-small">
            <h3 class="bf-text-small__title text-center">{title}</h3>
        </div>
    </div>
    <div class="col-md-6 order-md-1 d-flex">
        <div class="bf-img-wrap"><img class="bf-img" src="{img}" alt=""></div>
    </div>
</div>
