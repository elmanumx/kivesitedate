<?=$header;?>
<?=$nav;?>

<!-- Далее идёт код что бы под HEADER'ом был фон. Сделан костылём, потому что, на разных страницах, этот фон разный. иногда это совместный фон с секцией снизу -->
<div class="b-nav-background d-none d-sm-block"></div>
<!-- Далее идёт костыль для того, что бы было нормальное отображение этого фона на мобильном -->
<div class="b-nav-background-mobile d-flex d-block d-sm-none"></div>

<section class="for-girls">
    <div class="container">
        <div class="row no-gutters fg-row">
            <div class="col-md-6 d-flex align-items-top">
                <div class="fg-text__left">
                    <h3 class="fg-text__title text-left">
                        Уважаемые дамы!
                    </h3>
                    <p class="fg-text__paragraph text-left">
                        Вы одиноки и совсем недавно у вас случился развод с&nbsp;мужем? Вы разошлись с&nbsp;парнем и не&nbsp;верите больше в&nbsp;любовь? Либо же у&nbsp;вас все прекрасно, но просто не&nbsp;хватает любимого человека, друга и покровителя...<br><br>
                        Тогда вам несомненно к&nbsp;нам! Мы поможем вам найти нужного человека! Подарите себе шанс на&nbsp;любовь и&nbsp;счастливую семейную жизнь!
                    </p>
                    <div class="fg-text__link-wrap d-flex justify-content-end">
                        <a href="#fg-conditions" class="fg-text__link">Узнать условия</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 d-flex">
                <div class="fg-img-wrap">
                    <img class="fg-img" src="/application/public/img/for-girls/for-girls_1.jpg" alt="">
                </div>
            </div>
        </div>
        <div class="row no-gutters fg-row">
            <div class="col-md-6 order-md-2 d-flex align-items-center">
                <div class="fg-text__right">
                    <p class="fg-text__paragraph text-left">
                        РЕГИСТРАЦИЯ на нашем сайте является бесплатной и все что от вас требуется это корректно ввести ваши данные и&nbsp;загрузить фото (предпочтительно профессиональные и не&nbsp;меньше 5&nbsp;штук).<br><br>
                        Ваша анкета будет просмотрена представительными мужчинами из европейских стран, США, а так же других стран.
                    </p>
                    <div class="fg-text__link-wrap d-flex justify-content-end">
                        <a href="#profile" class="fg-text__link">Заполнить анкету</a>
                    </div>
                </div>
            </div>
            <div class="col-md-6 order-md-1 d-flex">
                <div class="fg-img-wrap">
                    <img class="fg-img" src="/application/public/img/for-girls/for-girls_2.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<section class="as-it">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="as-it__title">
                    Как все будет происходить?
                </h2>
            </div>
        </div>
        <div class="row no-gutters as-it-row">
            <div class="col-md-6 d-flex align-items-center">
                <div class="as-it-text__left">
                    <h3 class="as-it-text__title text-left">
                        Шаг 1.
                    </h3>
                    <p class="as-it-text__paragraph text-left">
                        Сначала заполните анкету на сайте, указав подробную информацию о&nbsp;себе:
                    </p>
                    <p class="as-it-text__paragraph_with-ident text-left">
                        Пожалуйста предоставляйте только реальную информацию (не&nbsp;скрывайте свой возраст либо наличие детей и&nbsp;т.д)
                    </p>
                    <p class="as-it-text__paragraph_italic text-left">
                        Не забудьте обязательно прикрепить свои фотографии, так&nbsp;как анкеты без фото мужчины не&nbsp; рассматривают!
                    </p>
                    <p class="as-it-text__paragraph_with-ident text-left">
                        Прикрепите удачные фото, на которых можно хорошо рассмотреть Ваши черты лица и особенности фигуры (снимки не&nbsp;должны быть вульгарными)
                    </p>
                    <p class="as-it-text__paragraph_with-ident d-block d-md-none d-lg-block">
                        Не&nbsp;создавайте фото с помощью фотошопа, несоответствие фотографий с реальной жизнью либо их не&nbsp;естественный вид может оттолкнуть мужчину
                    </p>
                    <p class="as-it-text__paragraph_italic d-block d-md-none d-lg-block text-left">
                        Мужчины несомненно оценят Вашу естественную красоту и&nbsp;качества!
                    </p>
                </div>
            </div>
            <div class="col-md-6 d-flex">
                <div class="as-it-img-wrap">
                    <img class="as-it-img" src="/application/public/img/for-girls/for-girls_step-1.jpg" alt="">
                </div>
            </div>
        </div>
        <div class="row no-gutters as-it-row">
            <div class="col-md-6 order-md-2 d-flex align-items-center">
                <div class="as-it-text__right">
                    <h3 class="as-it-text__title text-left">
                        Шаг 2.
                    </h3>
                    <p class="as-it-text__paragraph text-left">
                        После бесплатной регистрации на сайте нашего брачного агентства мы обязательно созвонимся с вами и уточним указанную информацию.
                    </p>
                </div>
            </div>
            <div class="col-md-6 order-md-1 d-flex">
                <div class="as-it-img-wrap">
                    <img class="as-it-img" src="/application/public/img/for-girls/for-girls_step-2.jpg" alt="">
                </div>
            </div>
        </div>
        <div class="row no-gutters as-it-row">
            <div class="col-md-6 d-flex align-items-center">
                <div class="as-it-text__left">
                    <h3 class="as-it-text__title text-left">
                        Шаг 3.
                    </h3>
                    <p class="as-it-text__paragraph text-left">
                        Просматривая Вашу анкету, мужчины будут выражать Вам симпатию, и среди них вы сможете выбрать того, с кем захотите встретиться лично.
                    </p>
                    <p class="as-it-text__paragraph_italic text-left">
                        Вы всегда имеете право отказать в свидании, указав при этом причину отказа!
                    </p>
                </div>
            </div>
            <div class="col-md-6 d-flex">
                <div class="as-it-img-wrap">
                    <img class="as-it-img" src="/application/public/img/for-girls/for-girls_step-3.jpg" alt="">
                </div>
            </div>
        </div>
        <div class="row no-gutters as-it-row">
            <div class="col-md-6 order-md-2 d-flex align-items-center">
                <div class="as-it-text__right">
                    <h3 class="as-it-text__title text-left">
                        Шаг 4.
                    </h3>
                    <p class="as-it-text__paragraph text-left">
                        Сотрудники нашего агентства организуют для Вас незабываемое первое приятное свидание в Киеве, либо в другом городе. При необходимости, для комфорта на первой встрече предоставляется переводчик.
                    </p>
                </div>
            </div>
            <div class="col-md-6 order-md-1 d-flex">
                <div class="as-it-img-wrap">
                    <img class="as-it-img" src="/application/public/img/for-girls/for-girls_step-4.jpg" alt="">
                </div>
            </div>
        </div>
    </div>
</section>
<section id="fg-conditions" class="conditions cond">
    <div class="container">
        <div class="row">
            <div class="col-12">
                <h2 class="cond__title text-center">
                    Условия сотрудничества
                </h2>
            </div>
        </div>
        <div class="row">
            <div class="col-md-4">
                <div class="cond__wrap d-flex flex-column align-items-center">
                    <img src="/application/public/img/for-girls/for-girls_conditions-1.jpg" alt="" class="cond__img">
                    <p class="cond__text text-center">
                        Внимание! Заполняя анкету, вы автоматически подтверждаете, что вам исполнилось полных 18 лет
                    </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="cond__wrap d-flex flex-column align-items-center">
                    <img src="/application/public/img/for-girls/for-girls_conditions-2.jpg" alt="" class="cond__img">
                    <p class="cond__text text-center">
                        Мужчинам будет видна указанная вами информация кроме контактных данных
                    </p>
                </div>
            </div>
            <div class="col-md-4">
                <div class="cond__wrap d-flex flex-column align-items-center">
                    <img src="/application/public/img/for-girls/for-girls_conditions-3.jpg" alt="" class="cond__img">
                    <p class="cond__text text-center">
                        Администрация KDA оставляет за собой право удалять анкету, которая не соответствует направленности нашего агентства
                    </p>
                </div>
            </div>
        </div>
    </div>
</section>
<section id="profile" class="profile">
    <div class="container">
        <form action="" id="profile-of-girl" method="post" class="profile-of-girl pofg">
            <div class="row">
                <div class="offset-lg-1 col-lg-10">
                    <h2 class="pofg__title text-center">
                        Для регистрации в&nbsp;агентстве — заполните анкету и&nbsp;нажмите кнопку отправить
                    </h2>
                </div>
            </div>
            <div class="row">
                <div class="col-lg-7">
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__last-name" class="pofg__label">1. Фамилия:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="l_name" id="pofg__last-name" type="text" class="pofg__input pofg__input_last-name">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__first-name" class="pofg__label">2. Имя:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="name" id="pofg__first-name" type="text" class="pofg__input pofg__input_first-name">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__city" class="pofg__label">3. Город:</label>
                        </div>
                        <div class="col-sm-5">
                            <select name="city" id="pofg__city" class="pofg__input pofg__input_city">
                                <option value="Kiev">Киев</option>
                                <option value="another region">другой регион</option>
                            </select>
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__height" class="pofg__label">4. Рост:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="height" id="pofg__height" type="text" class="pofg__input pofg__input_height">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__weight" class="pofg__label">5. Вес:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="weight" id="pofg__weight" type="text" class="pofg__input pofg__input_weight">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__age" class="pofg__label">6. Возраст:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="age" id="pofg__age" type="text" class="pofg__input pofg__input_age">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__eye-color" class="pofg__label">7. Цвет глаз:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="color_eye" id="pofg__eye-color" type="text" class="pofg__input pofg__input_eye-color">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__hair-color" class="pofg__label">8. Цвет волос:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="color_heir" id="pofg__hair-color" type="text" class="pofg__input pofg__input_hair-color">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__education" class="pofg__label">9. Образование:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="education" id="pofg__education" type="text" class="pofg__input pofg__input_education">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__profession" class="pofg__label">10. Профессия</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="profession" id="pofg__profession" type="text" class="pofg__input pofg__input_profession">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__occupation" class="pofg__label">11. Род занятий:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="occupation" id="pofg__occupation" type="text" class="pofg__input pofg__input_occupation">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__religion" class="pofg__label">12. Религия:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="religion" id="pofg__religion" type="text" class="pofg__input pofg__input_religion">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__smoking" class="pofg__label">13. Курение:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="smoking" id="pofg__smoking" type="text" class="pofg__input pofg__input_smoking">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__alcohol" class="pofg__label">14. Спиртное:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="alcohol" id="pofg__alcohol" type="text" class="pofg__input pofg__input_alcohol">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__knowledge-of-english" class="pofg__label">15. Знание английского:</label>
                        </div>
                        <div class="col-sm-5">
                            <select name="lang_eng" id="pofg__knowledge-of-english" class="pofg__input pofg__input_knowledge-of-english">
                                <option value="basic">Базовый уровень</option>
                                <option value="good">Уверенное владение</option>
                            </select>
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__other-languages" class="pofg__label">16. Другие иностранные языки:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="lang_other" id="pofg__other-languages" type="text" class="pofg__input pofg__input_other-languages">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__marital-status" class="pofg__label">17. Семейное положение:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="family_status" id="pofg__marital-status" type="text" class="pofg__input pofg__input_marital-status">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__amount-of-children" class="pofg__label">18. Число детей:</label>
                        </div>
                        <div class="col-sm-5">
                            <select name="children_count" id="pofg__amount-of-children" class="pofg__input pofg__input_amount-of-children">
                                <option value="0">Нет детей</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                            </select>
                        </div>
                    </div>
                    <div class="row pofg__group-textarea d-flex flex-column">
                        <div class="col-12">
                            <label for="pofg__about-you" class="pofg__label">19. О себе: (и о своем характере в нескольких предложениях)</label>
                        </div>
                        <div class="col-12">
                            <textarea name="about" id="pofg__about-you" class="pofg__textarea pofg__textarea_about-you"></textarea>
                        </div>
                    </div>
                    <h6 class="pofg__subtitle">
                        О партнёре
                    </h6>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__age-of-man" class="pofg__label">21. Возраст мужчины: (от-до)</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="man_age" id="pofg__age-of-man" type="text" class="pofg__input pofg__input_age-of-man">
                        </div>
                    </div>
                    <div class="row pofg__group-textarea d-flex flex-column">
                        <div class="col-12">
                            <label for="pofg__man-type" class="pofg__label">22. Тип мужчины: (какого мужчину вы видите своим избранником; перечислите качества характера, которые больше всего нравятся в мужчинах)</label>
                        </div>
                        <div class="col-12">
                            <textarea name="man_about" id="pofg__man-type" class="pofg__textarea pofg__textarea_man-type"></textarea>
                        </div>
                    </div>
                    <h6 class="pofg__subtitle">
                        Контактные данные
                    </h6>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__email" class="pofg__label">23. Электронный адрес:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="mail" id="pofg__email" type="email" class="pofg__input pofg__input_email">
                        </div>
                    </div>
                    <div class="row pofg__group-items">
                        <div class="col-sm-7">
                            <label for="pofg__phone-number" class="pofg__label">24. Контактный телефон:</label>
                        </div>
                        <div class="col-sm-5">
                            <input name="phone" id="pofg__phone-number" type="tel" class="pofg__input pofg__input_phone-number">
                        </div>
                    </div>
                </div>
                <div class="col-lg-5">
                    <div id="all_photo_girl" class="row pofg__row-wrap-img d-flex flex-wrap">  
                        <div class="col-12 col-sm-6 col-md-4 col-lg-6">
                            <div class="pofg__wrap-photo">
                                <div class="pofg__wrap-upload">
                                    <label class="pofg__upload-label">
                                        Добавить <br> фото
                                    </label>
                                    <input id="upload_photo_girl" type="file" class="pofg__plus-upload">
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-12 d-flex justify-content-center">
                   <input name="sub_add_girl" class="pofg__sent-form" type="submit" value="Отправить анкету">
                </div>
            </div>
        </form>
    </div>
</section>

<?=$footer?>
<script>
    $('#upload_photo_girl').change(function() {
        let files = this.files;
        sendFilesNew(files);
    });
    
    $('body').on('click', '.delete_photo_girl', function() {
        var src = $(this).siblings('.img_girl_one').attr('src');
        $.ajax({
            type: "POST",
            data: {
                delete_photo_girl: 1,
                src: src
            }
        });
        $(this).closest('.one_girl_photo').remove();
    });

    function sendFilesNew(files) {
        let maxFileSize = 5242880;
        let Data = new FormData();
        $(files).each(function(index, file) {
            if ((file.size <= maxFileSize) && ((file.type == 'image/png') || (file.type == 'image/jpeg'))) {
                Data.append('images[]', file);
            }
        });
        $.ajax({
            type: "POST",
            data: Data,
            contentType: false,
            processData: false,
            success: function(data) {
                data = JSON.parse(data);
                $('.one_girl_photo').remove();
                
                for (var el in data) {
                    $('#all_photo_girl').prepend('<div class="one_girl_photo col-12 col-sm-6 col-md-4 col-lg-6"><div class="pofg__wrap-photo"><input type="button"  title="Click to delete this photo" class="a-bf__delete delete_photo_girl"><img src="' + data[el] + '" alt="" class="img_girl_one pofg__upload-photo"></div></div>');
                }
            }
        });
    }

</script>