<!-- Block 6 -->
<!-- <div class="row no-gutters bf-row_auto-height"><div class="col-md-6 d-flex align-items-center"><div class="bf-only-text"><p class="bf-only-text__paragraph text-center">{text1}</p></div></div><div class="col-md-6 d-flex align-items-center"><div class="bf-only-text"><p class="bf-only-text__paragraph text-center">{text2}</p></div></div></div>
<!-- -->
<div class="row no-gutters bf-row_auto-height">
    <div class="col-md-6 d-flex align-items-center">
        <div class="bf-only-text">
            <p class="bf-only-text__paragraph text-center">{text1}</p>
        </div>
    </div>
    <div class="col-md-6 d-flex align-items-center">
        <div class="bf-only-text">
            <p class="bf-only-text__paragraph text-center">{text2}</p>
        </div>
    </div>
</div>
